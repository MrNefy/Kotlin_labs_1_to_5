package com.galucinogen.library.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
}
