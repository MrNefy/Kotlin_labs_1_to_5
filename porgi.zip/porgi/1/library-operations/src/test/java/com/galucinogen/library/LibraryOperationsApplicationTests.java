package com.galucinogen.library;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryOperationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
